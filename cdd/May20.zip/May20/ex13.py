#finditer()
import re

match=re.finditer('\d', 'sandesh6460')

for m in match:
	print(m.start(),m.end(),m.group())

# o/p:
# -----
# start end group
# 7      8      6
# 8      9      4
# 9      10     6
# 10     11     0
------------------------------------------------------
match=re.finditer('\W', '$andesh_64 60')

for m in match:
	print(m.start(),m.end(),m.group())

# o/p:
# -----
# start end group
# 0       1     $
# 10      11 

NOTE:
-----
--> _ is not a special character