#findall()
import re

p=input('Enter the pattern:\t')
s=input('Enter the target string:\t ')

lst=re.findall(p, s)
print(lst)

# o/p:
# ----
# Enter the pattern:	6460
# Enter the target string:	 sandesh6460
# ['6460']
# -----------------------------------------------
# Enter the pattern:	7878
# Enter the target string:	 sandesh6460
# []