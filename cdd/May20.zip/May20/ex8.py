#match()
import re

p=input('Enter the pattern:\t')
s=input('Enter the  target string:\t ')

data = re.match(p,s)
if data==None:
	print('Match is not available at the beginning of the target string')

else:
	print('Match is available at the beginning of the target string')
	print('start index: {} end index:{}'.format(data.start(),data.end()))

# o/p:
# -----
# Enter the pattern:	san
# Enter the  target string:	 sandesh
# Match is available at the beginning of the target string
# start index: 0 end index:3
----------------------------------------------------------------
# Enter the pattern:	sandy
# Enter the  target string:	 sandeshhsy
# Match is not available at the beginning of the target string
# ---------------------------------------------------------------