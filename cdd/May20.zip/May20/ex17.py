#compile()
#  syntax :  compile(pattern)
import re

my_pattern=re.compile('python')
print(my_pattern)
print(type(my_pattern))
