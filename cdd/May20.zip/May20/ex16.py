#split()
import re

data=re.split('-', 'san-desh-6460-abc')
print(data)#['san', 'desh', '6460', 'abc']

# ------------------------------------------------------

data=re.split('.', 'www.google.com')
print(data)#['', '', '', '', '', '', '', '', '', '', '', '', '', '', '']

#---------------------------------------------------------
data=re.split('\.', 'www.google.com')
print(data)#['www', 'google', 'com']

#------------------------------------------------------------
data=re.split(',', 'sandesh,suhas,akash')
print(data)#['sandesh', 'suhas', 'akash']

#------------------------------------------------------------
