import re


lst=re.findall('[\d]', 'sandesh6460')
print(lst)


# o/p:
# -----
# ['6', '4', '6', '0']