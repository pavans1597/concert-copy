#search()
import re

p=input('Enter the pattern:\t')
s=input('Enter the target string:\t ')

data = re.search(p,s)

if data!=None:
	print('match is available')
	print('First occurrence : start index: {} end index:{}'.format(data.start(),data.end()))

else:
	print('match is not available')

# o/p:
# ------
# Enter the pattern:	s
# Enter the target string:	 sandeshhs
# match is available
# First occurrence : start index: 0 end index:1
#-------------------------------------------------------------------------
# Enter the pattern:	abc
# Enter the target string:	 abcinabcbyabctoabc
# match is available
# First occurrence : start index: 0 end index:3
# ------------------------------------------------------------------------
# # Enter the pattern:	sa 
# Enter the target string:	 abcfortechnology
# match is not available
