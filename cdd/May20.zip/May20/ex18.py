# ^symbol
import re
s='learning python is very easy'
result=re.search('^learn', s)
print(result)
if result!=None:
	print('Target string starts with the given pattern')
else:
	print('Target string does not starts with the given pattern')

# o/p:
# ------
# <re.Match object; span=(0, 5), match='learn'>
# Target string starts with the given pattern
# -------------------------------------------------------------

result=re.search('^tearn', s)

if result!=None:
	print('Target string starts with the given pattern')
else:
	print('Target string does not starts with the given pattern')

# o/p:
# ----
# Target string does not starts with the given pattern
# ------------------------------------------------------------------
s='learning python is very easy'
result=re.search('^Learn', s,re.I)

if result!=None:
	print('Target string starts with the given pattern')
else:
	print('Target string does not starts with the given pattern')