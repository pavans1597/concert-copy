#subn()
import re

s=re.subn('\d', '#', 'sandesh6460san963')
print(s)
print(type(s))
print('o/p string:',s[0])
print('no of replacements:',s[1])