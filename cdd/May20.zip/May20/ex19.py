# $ symbol
import re
s='learning python is very easy'
result=re.search('easy$', s)
print(result)
if result!=None:
	print('Target string ends with the given pattern')
else:
	print('Target string does not ends with the given pattern')

# o/p:
# -----
# <re.Match object; span=(24, 28), match='easy'>
# Target string ends with the given pattern
# ---------------------------------------------------------------------------

result=re.search('eas$', s)
print(result)
if result!=None:
	print('Target string ends with the given pattern')
else:
	print('Target string does not ends with the given pattern')

# o/p:
# -----
# None
# Target string does not ends with the given pattern
# ----------------------------------------------------------------------------

s='learning python is very easy'
result=re.search('Easy$', s,re.IGNORECASE)

if result!=None:
	print('Target string ends with the given pattern')
else:
	print('Target string does not ends with the given pattern')

# o/p:
# -----
# Target string ends with the given pattern
# ---------------------------------------------------------------------------