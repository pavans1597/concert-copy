#sub()
import re

s=re.sub('\d', '#', 'sandesh6460san963')
print(s)
print(type(s))