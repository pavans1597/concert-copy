#fullmatch()
import re

p=input('Enter the pattern:\t')
s=input('Enter the  target string:\t ')

data = re.fullmatch(p,s)
if data==None:
	print('full Match is not available at the target string')

else:
	print('full Match is available at the target string')
	print('start index: {} end index:{}'.format(data.start(),data.end()))


# o/p:
# ----
# Enter the pattern:	abcfortechnology
# Enter the  target string:	 abcfortechnology
# full Match is available at the target string
# start index: 0 end index:16
-------------------------------------------------
# Enter the pattern:	abc
# Enter the  target string:	 abcforpython
# full Match is not available at the target string
